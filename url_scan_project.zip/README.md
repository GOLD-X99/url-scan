# URL Security Scanner

A small educational Flask project that performs basic URL inspection.

## Features
- URL format parsing
- HTTP/HTTPS detection
- DNS/IP lookup
- Port detection
- Suspicious keyword detection
- Basic heuristic risk score
- Detection of some potentially misleading URL patterns
- Simple web interface

## Requirements
- Python 3.10 or newer
- Internet connection for DNS/TLS checks

## Windows installation and run

1. Extract the ZIP file.
2. Open Command Prompt inside the project folder.
3. Create a virtual environment:

   `python -m venv venv`

4. Activate it:

   `venv\Scripts\activate`

5. Install dependencies:

   `pip install -r requirements.txt`

6. Start the app:

   `python app.py`

7. Open this address in your browser:

   `http://127.0.0.1:5000`

## Android / Termux
Install Python and run the same Flask commands if your Termux setup supports them.

## Important
This is an educational heuristic scanner. A low score does NOT guarantee that a URL is safe, and a high score does NOT prove that it is malicious.

Only scan URLs you are authorized to inspect.
