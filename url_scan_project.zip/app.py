from flask import Flask, render_template, request
from urllib.parse import urlparse
import socket
import ssl
import re
from datetime import datetime

app = Flask(__name__)

SUSPICIOUS_WORDS = [
    "login", "verify", "verification", "secure", "account",
    "update", "password", "bank", "paypal", "wallet", "confirm"
]

def normalize_url(url):
    url = url.strip()
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    return url

def scan_url(raw_url):
    url = normalize_url(raw_url)
    result = {
        "url": url,
        "valid": False,
        "scheme": "",
        "domain": "",
        "ip": "",
        "port": "",
        "https": False,
        "suspicious_words": [],
        "issues": [],
        "score": 0,
        "scanned_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    try:
        parsed = urlparse(url)

        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            result["issues"].append("Invalid URL format.")
            return result

        result["valid"] = True
        result["scheme"] = parsed.scheme
        result["domain"] = parsed.hostname
        result["port"] = parsed.port or (443 if parsed.scheme == "https" else 80)
        result["https"] = parsed.scheme == "https"

        try:
            result["ip"] = socket.gethostbyname(parsed.hostname)
        except socket.gaierror:
            result["issues"].append("Domain could not be resolved.")
            result["score"] += 30

        lower_url = url.lower()
        result["suspicious_words"] = [
            word for word in SUSPICIOUS_WORDS if word in lower_url
        ]
        result["score"] += min(len(result["suspicious_words"]) * 8, 40)

        if not result["https"]:
            result["issues"].append("Connection is not using HTTPS.")
            result["score"] += 25

        if "@" in url:
            result["issues"].append("URL contains '@', which can be misleading.")
            result["score"] += 25

        if parsed.hostname and len(parsed.hostname) > 50:
            result["issues"].append("Domain is unusually long.")
            result["score"] += 10

        if parsed.hostname and parsed.hostname.count(".") >= 4:
            result["issues"].append("Domain has many subdomain levels.")
            result["score"] += 10

        if re.search(r"https?://\d{1,3}(\.\d{1,3}){3}", url):
            result["issues"].append("URL uses an IP address instead of a domain.")
            result["score"] += 20

        if result["https"]:
            try:
                context = ssl.create_default_context()
                with socket.create_connection((parsed.hostname, 443), timeout=3) as sock:
                    with context.wrap_socket(sock, server_hostname=parsed.hostname):
                        pass
            except Exception:
                result["issues"].append("Could not verify the TLS connection.")
                result["score"] += 10

        result["score"] = min(result["score"], 100)
        return result

    except Exception as exc:
        result["issues"].append(f"Scan error: {type(exc).__name__}.")
        return result

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        result = scan_url(request.form.get("url", ""))
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
